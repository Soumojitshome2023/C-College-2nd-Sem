#include<stdio.h>
#include<string.h>

int main(){
   // 2. Write a C program to count the total number of vowels and consonants in a string.
    char ch[30];
    int len =0,i=0,vowel=0,consonant=0;
    
    printf("Enter string : ");
    gets(ch);
    
    while(ch[i]!='\0'){
        len++;
        if(ch[i]=='A' || ch[i]=='E' ||ch[i]=='I' || ch[i]=='O' ||ch[i]=='U' ||ch[i]=='a' || ch[i]=='e' ||ch[i]=='i' || ch[i]=='o' ||ch[i]=='u')
            vowel++;
        else if(ch[i]!=' ')
            consonant++;
   
     i++;
    }
    
     printf("Length is %d\n",len);
    printf("The total number of vowels = %d\n",vowel);
    printf("The total number of consonants = %d\n",consonant);

    return 0;

}
